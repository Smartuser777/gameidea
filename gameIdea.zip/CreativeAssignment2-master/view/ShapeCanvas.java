package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.Circle;
import model.Circle2;
import model.Shape;

public class ShapeCanvas extends JPanel {

    private ShapePanel panel;
	//private Color chooseColor = Color.GREEN;
    private ArrayList<Shape> shapes = new ArrayList<>();

    public ShapeCanvas(ShapePanel panel) {
        this.panel = panel;
        setPreferredSize(new Dimension(500, 500));
        setBackground(Color.BLACK);

        shapes.add(new Circle(50, 50, Color.MAGENTA, 50));
        shapes.add(new Circle2(100, 100, Color.YELLOW, 70));

    }

    @Override

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        for (var s : shapes) {
           s.render(g2);
		}
	}
		/*if(chooseColor.equals(Color.YELLOW))
        {
            chooseColor = Color.GREEN;
        }
        else
        {
            chooseColor = Color.YELLOW;
        }
        g.setColor(chooseColor);
        g.fillOval(25, 25, 10, 10);
    } */


    public ArrayList<Shape> getShapes() {
        return shapes;
    }
}